<div class="footer">
	<div class="footer-inner">
		<div class="container">
			<div class="row">
				<div class="span12"> &copy; <?php echo date('Y');?> <?php echo anchor(base_url(), base_url(),array('target'=>'blank')); ?>. </div>
			<!-- /span12 --> 
			</div>
		  <!-- /row --> 
		</div>
		<!-- /container --> 
	</div>
	<!-- /footer-inner --> 
</div>
