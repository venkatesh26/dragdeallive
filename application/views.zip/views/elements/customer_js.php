<!-- external javascript -->
<script type="text/javascript" src="<?php echo base_url();?>assets/js/jquery-ui.min.js"></script>
<script src="<?php echo base_url().'assets/customer';?>/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>


<!-- data table plugin -->
<script src='<?php echo base_url().'assets/customer';?>/js/jquery.dataTables.min.js'></script>

<script src="<?php echo base_url().'assets/customer';?>/bower_components/colorbox/jquery.colorbox-min.js"></script>

<!-- library for making tables responsive -->
<script src="<?php echo base_url().'assets/customer';?>/bower_components/responsive-tables/responsive-tables.js"></script>

<!-- for iOS style toggle switch -->
<script src="<?php echo base_url().'assets/customer';?>/js/jquery.iphone.toggle.js"></script>
<!-- autogrowing textarea plugin -->
<script src="<?php echo base_url().'assets/customer';?>/js/jquery.autogrow-textarea.js"></script>
<script src="<?php echo base_url().'assets/customer';?>/js/jquery.cookie.js"></script>
<script src="<?php echo base_url().'assets/customer';?>/js/charisma.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/jquery.amaran.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/jquery.livequery.js"></script>
<script src="<?php echo base_url();?>assets/customer/js/dataTables.tableTools.min.js"></script>
<script src="<?php echo base_url();?>assets/customer/js/datatables.responsive.js"></script>
<script src="<?php echo base_url();?>assets/customer/js/lodash.min.js"></script>
<script src="<?php echo base_url();?>assets/customer/js/datatables.js"></script>
<script src="<?php echo base_url();?>assets/customer/js/bootstrap-timepicker.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/customer/js/jquery.tokenize.js"></script>
<script src="<?php echo base_url();?>assets/customer/js/loadingoverlay.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/customer/js/common.js"></script>