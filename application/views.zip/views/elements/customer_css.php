	<link href="<?php echo base_url().'assets/customer';?>/css/theme_default.css" rel="stylesheet">
	<!--<link id="bs-css" href="<?php echo base_url().'assets/customer';?>/css/bootstrap-darkly.min.css" rel="stylesheet">-->
    <link href="<?php echo base_url().'assets/customer';?>/css/charisma-app.css" rel="stylesheet">
    <link href='<?php echo base_url().'assets/customer';?>/bower_components/fullcalendar/dist/fullcalendar.css' rel='stylesheet'>
    <link href='<?php echo base_url().'assets/customer';?>/bower_components/fullcalendar/dist/fullcalendar.print.css' rel='stylesheet' media='print'>
    <link href='<?php echo base_url().'assets/customer';?>/bower_components/chosen/chosen.min.css' rel='stylesheet'>
    <link href='<?php echo base_url().'assets/customer';?>/bower_components/colorbox/example3/colorbox.css' rel='stylesheet'>
    <link href='<?php echo base_url().'assets/customer';?>/bower_components/responsive-tables/responsive-tables.css' rel='stylesheet'>
    <link href='<?php echo base_url().'assets/customer';?>/bower_components/bootstrap-tour/build/css/bootstrap-tour.min.css' rel='stylesheet'>
    <link href='<?php echo base_url().'assets/customer';?>/css/jquery.noty.css' rel='stylesheet'>
	<link href='<?php echo base_url().'assets/customer';?>/css/noty_theme_default.css' rel='stylesheet'>
	<link href='<?php echo base_url().'assets/customer';?>/css/elfinder.min.css' rel='stylesheet'>
    <link href='<?php echo base_url().'assets/customer';?>/css/elfinder.theme.css' rel='stylesheet'>
    <link href='<?php echo base_url().'assets/customer';?>/css/jquery.iphone.toggle.css' rel='stylesheet'>
    <link href='<?php echo base_url().'assets/customer';?>/css/uploadify.css' rel='stylesheet'>
    <link href='<?php echo base_url().'assets/customer';?>/css/animate.min.css' rel='stylesheet'>
	<link type="text/css" rel="stylesheet" href="<?php echo base_url();?>assets/css/amaran.min.css" media="screen"/>
	<link type="text/css" rel="stylesheet" href="<?php echo base_url();?>assets/css/jquery-ui.min.css" media="screen"/>
	
	<link rel="stylesheet" href="<?php echo base_url().'assets/customer';?>/css/jquery.dataTables.css"/>
	<link rel="stylesheet" href="<?php echo base_url().'assets/customer';?>/css/datatables.responsive.css"/><!-- DataTable -->
	<link rel="stylesheet" href="<?php echo base_url().'assets/customer';?>/css/bootstrap-timepicker.min.css"/>
	<link rel="stylesheet" href="<?php echo base_url().'assets/customer';?>/css/bootstrap-datepicker.min.css"/>
	<link href='<?php echo base_url().'assets/customer';?>/css/jquery.tokenize.css' rel='stylesheet'>
	<link href='<?php echo base_url().'assets/customer';?>/css/custom.css' rel='stylesheet'>
	<link href='<?php echo base_url().'assets/customer';?>/css/dataTables.bootstrap.min.css' rel='stylesheet'>

<link type="text/css" rel="stylesheet" href="<?php echo base_url();?>assets/css/fonts/fonts.css" media="screen"/>
<link type="text/css" rel="stylesheet" href="<?php echo base_url();?>assets/css/font-awesome.css" media="screen"/>