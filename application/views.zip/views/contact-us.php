<div class="td-main-content-wrap td-main-page-wrap">
                <div class="td-container ">
  <?php /************ Bread Crumb *****************/ echo $this->load->view('bread_crumb',array(),true); ?>
<div class="td-pb-row">
<div class="td-pb-span12 td-main-content" role="main">
<div class="td-ss-main-content">
<div class="td-page-header">
<h1 class="entry-title td-page-title">
<span>Contact</span>
</h1>
</div>
<div class="td-pb-padding-side td-page-content">
<div class="vc_row wpb_row td-pb-row"><div class="wpb_column vc_column_container td-pb-span8"><div class="wpb_wrapper">
<div class="wpb_text_column wpb_content_element ">
<div class="wpb_wrapper">
<p>For Businesses: Want to increase the number of customers? Need an advertising medium which will give you the best Return on Investment(ROI)? Which dragdeal.com is the medium you needed. Information anytime anywhere : The information is available across online voice.</p>
</div>
</div>
<div class="vc_row wpb_row vc_inner td-pb-row"><div class="wpb_column vc_column_container td-pb-span6"><div class="vc_column-inner "><div class="wpb_wrapper"><div class="td_block_wrap td_block_text_with_title td_uid_15_574c663d8ea36_rand td-pb-border-top" data-td-block-uid="td_uid_15_574c663d8ea36"><h4 class="block-title"><span>Contact Details</span></h4><div class="td_mod_wrap"><strong>Dragdeal</strong><br>Chennai.<p></p>
<p>Email: <strong><a href="mailto:info@dragdeal.com" target="_blank">info@dragdeal.com</a></strong></p></div></div></div></div></div><div class="wpb_column vc_column_container td-pb-span6"><div class="vc_column-inner "><div class="wpb_wrapper"><div class="td_block_wrap td_block_text_with_title td_uid_16_574c663d8ec76_rand td-pb-border-top" data-td-block-uid="td_uid_16_574c663d8ec76"><h4 class="block-title"><span>About us</span></h4><div class="td_mod_wrap">
<strong>dragdeal.com</strong> provides a excellent information services between local business and users in various cities across India. We Provide the most accurate data to users and businesses. Our Mission: Our mission is to provide genuine information to users in fast manner.</div></div></div></div></div></div><div class="vc_row wpb_row vc_inner td-pb-row"><div class="wpb_column vc_column_container td-pb-span12"><div class="vc_column-inner "><div class="wpb_wrapper">
<div class="wpb_raw_code wpb_content_element wpb_raw_html">
<div class="wpb_wrapper">
<h4 class="block-title"><span>Send us a message!</span></h4>
</div>
</div>
<div role="form" class="wpcf7" lang="en-US" dir="ltr">
<div class="screen-reader-response"></div>
<form action="<?php echo base_url().'home/contact_us';?>" method="post"  id="contact_form_url">

<p><span class="wpcf7-form-control-wrap"><input type="text" name="name" value="" placeholder="Enter Your Name *" size="40" aria-required="true" aria-invalid="false"></span></p>

<p><span class="wpcf7-form-control-wrap"><input type="text" name="contact_number" value="" placeholder="Enter Your Contact Number *" size="40" aria-required="true" aria-invalid="false"></span></p>

<p><span class="wpcf7-form-control-wrap"><input type="text" name="email" value="" placeholder="Enter Your Email *" size="40" aria-required="true" aria-invalid="false"></span></p>

<p><span class="wpcf7-form-control-wrap"><input type="text" name="title" value="" placeholder="Enter Title *" size="40" aria-required="true" aria-invalid="false"></span></p>


<p><span class="wpcf7-form-control-wrap your-message"><textarea placeholder="Enter Your Message *" name="message" cols="40" rows="10" class="wpcf7-form-control wpcf7-textarea" aria-invalid="false"></textarea></span></p>

<p><input type="submit" value="Send" class="wpcf7-form-control wpcf7-submit contactus_form_submit" style="float:right;"></p>
<div class="wpcf7-response-output wpcf7-display-none"></div></form>

</div></div></div></div></div></div></div><div class="wpb_column vc_column_container td-pb-span4"><div class="wpb_wrapper">
<div class="td-a-rec td-a-rec-id-sidebar "><span class="td-adspot-title">- Advertisement -</span>
<div class=td-visible-desktop>
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- newtheme customsize -->
<ins class="adsbygoogle"
     style="display:inline-block;width:300px;height:250px"
     data-ad-client="ca-pub-2739505616311307"
     data-ad-slot="2323491279"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
                                </div>
                                <div class=td-visible-tablet-landscape>
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- newtheme customsize -->
<ins class="adsbygoogle"
     style="display:inline-block;width:300px;height:250px"
     data-ad-client="ca-pub-2739505616311307"
     data-ad-slot="2323491279"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
                                </div>
                                <div class=td-visible-tablet-portrait>
                                  <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- newtheme customsize1 -->
<ins class="adsbygoogle"
     style="display:inline-block;width:200px;height:200px"
     data-ad-client="ca-pub-2739505616311307"
     data-ad-slot="3800224475"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
                                </div>
                                <div class=td-visible-phone>
                                    <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- newtheme customsize -->
<ins class="adsbygoogle"
     style="display:inline-block;width:300px;height:250px"
     data-ad-client="ca-pub-2739505616311307"
     data-ad-slot="2323491279"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
                                </div>
</div></div></div></div>
</div>
</div>
</div>
</div>
</div>
			</div>
				
		