<div class="td-main-content-wrap td-main-page-wrap">
                <div class="td-container ">
  <?php /************ Bread Crumb *****************/ echo $this->load->view('bread_crumb',array(),true); ?>
<div class="td-pb-row">
<div class="td-pb-span12 td-main-content" role="main">
<div class="td-ss-main-content">
<div class="td-page-header">
<h1 class="entry-title td-page-title">
<span>About Us</span>
</h1>
</div>
<div class="td-pb-padding-side td-page-content">
<div class="vc_row wpb_row td-pb-row"><div class="wpb_column vc_column_container td-pb-span8"><div class="wpb_wrapper">
<div class="wpb_text_column wpb_content_element ">
<div class="wpb_wrapper">
<p>For Businesses: Want to increase the number of customers? Need an advertising medium which will give you the best Return on Investment(ROI)? Which dragdeal.com is the medium you needed. Information anytime anywhere : The information is available across online voice.</p>
<p><strong>Why dragdeal.com?</strong></p>
<p>
dragdeal.com provides a excellent information services between local business and users in various cities across India. We Provide the most accurate data to users and businesses. Our Mission: Our mission is to provide genuine information to users in fast manner.
</p>
<p>For Businesses: Want to increase the number of customers? Need an advertising medium which will give you the best Return on Investment(ROI)? Which dragdeal.com is the medium you needed. Information anytime anywhere : The information is available across online voice.</p>
</div>
</div>
</div>
</div>

<div class="wpb_column vc_column_container td-pb-span4"><div class="wpb_wrapper">
<div class="td-a-rec td-a-rec-id-sidebar "><span class="td-adspot-title">- Advertisement -</span>
<div class=td-visible-desktop>
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- newtheme customsize -->
<ins class="adsbygoogle"
     style="display:inline-block;width:300px;height:250px"
     data-ad-client="ca-pub-2739505616311307"
     data-ad-slot="2323491279"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
                                </div>
                                <div class=td-visible-tablet-landscape>
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- newtheme customsize -->
<ins class="adsbygoogle"
     style="display:inline-block;width:300px;height:250px"
     data-ad-client="ca-pub-2739505616311307"
     data-ad-slot="2323491279"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
                                </div>
                                <div class=td-visible-tablet-portrait>
                                  <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- newtheme customsize1 -->
<ins class="adsbygoogle"
     style="display:inline-block;width:200px;height:200px"
     data-ad-client="ca-pub-2739505616311307"
     data-ad-slot="3800224475"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
                                </div>
                                <div class=td-visible-phone>
                                    <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- newtheme customsize -->
<ins class="adsbygoogle"
     style="display:inline-block;width:300px;height:250px"
     data-ad-client="ca-pub-2739505616311307"
     data-ad-slot="2323491279"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
                                </div>
</div></div></div></div>
</div>
</div>
</div>
</div>
</div>
			</div>
				
		