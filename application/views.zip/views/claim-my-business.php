<div class="td-main-content-wrap td-main-page-wrap">
                <div class="td-container ">
  <?php /************ Bread Crumb *****************/ echo $this->load->view('bread_crumb',array(),true); ?>
<div class="td-pb-row">
<div class="td-pb-span12 td-main-content" role="main">
<div class="td-ss-main-content">
<div class="td-page-header">
<h1 class="entry-title td-page-title">
</h1>
</div>
<div class="td-pb-padding-side td-page-content">
<div class="vc_row wpb_row td-pb-row"><div class="wpb_column vc_column_container td-pb-span8"><div class="wpb_wrapper">


<div class="vc_row wpb_row vc_inner td-pb-row"><div class="wpb_column vc_column_container td-pb-span12"><div class="vc_column-inner "><div class="wpb_wrapper">
<div class="wpb_raw_code wpb_content_element wpb_raw_html">
<div class="wpb_wrapper">
<h4 class="block-title"><span>Claim My Bussiness !</span></h4>
</div>
</div>
<div role="form" class="wpcf7" lang="en-US" dir="ltr">
<div class="screen-reader-response"></div>
<form action="<?php echo base_url().'home/claim_my_bussiness';?>" method="post"  id="claim_form_url">

<p><span class="wpcf7-form-control-wrap"><input type="text" name="name" value="" placeholder="Enter Your Name *" size="40" aria-required="true" aria-invalid="false"></span></p>

<p><span class="wpcf7-form-control-wrap"><input type="text" name="email" value="" placeholder="Enter Your Email *" size="40" aria-required="true" aria-invalid="false"></span></p>

<p><span class="wpcf7-form-control-wrap"><input type="text" name="contact_number" value="" placeholder="Enter Your Contact Number *" size="40" aria-required="true" aria-invalid="false"></span></p>

<p><span class="wpcf7-form-control-wrap"><input type="text" name="url" value="" placeholder="Enter Your Bussiness Url In Dragdeal *" aria-required="true" aria-invalid="false"></span></p>

<p><span class="wpcf7-form-control-wrap your-message"><textarea placeholder="Enter Your Message *" name="message" cols="40" rows="10" class="wpcf7-form-control wpcf7-textarea" aria-invalid="false"></textarea></span></p>

<p><span class="wpcf7-form-control-wrap"><input type="checkbox" name="is_account" id="is_account" value="1"><label for="is_account"> I Have Account In Dragdeal</label></span></p>

<p><input type="submit" value="Send" class="wpcf7-form-control wpcf7-submit contactus_form_submit" style="float:right;"></p>
<div class="wpcf7-response-output wpcf7-display-none"></div></form>

</div></div></div></div></div></div></div><div class="wpb_column vc_column_container td-pb-span4"><div class="wpb_wrapper">
<div class="td-a-rec td-a-rec-id-sidebar "><span class="td-adspot-title">- Advertisement -</span>
<div>
	<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
	<!-- newtheme customsize -->
	<ins class="adsbygoogle"
		 style="display:inline-block;width:300px;height:250px"
		 data-ad-client="ca-pub-2739505616311307"
		 data-ad-slot="2323491279"></ins>
	<script>
	(adsbygoogle = window.adsbygoogle || []).push({});
	</script>
</div>
</div></div></div></div>
</div>
</div>
</div>
</div>
</div>
</div>
				
		