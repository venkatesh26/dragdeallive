<tr>
	<td align="left" valign="top" style="padding-left:20px;padding-top:20px;padding-bottom:20px;border:1px solid #ccc;border-width:0px 1px 0px 1px;font:normal 12px Tahoma;">
		Dear <?php echo '<span style="font-weight:bold;">'.ucfirst($user_name).'</span>'; ?>, <br/><br/>
		Claim Your bussiness today.You Can update your profile and boost your bussiness.
	 <br/>
	 <br/>
		You can access your account please <?php echo anchor(base_url().'login', 'Click here'); ?>
	</td>        
</tr>