<tr>
	<td align="left" valign="top" style="padding-left:20px;padding-top:20px;padding-bottom:20px;border:1px solid #ccc;border-width:0px 1px 0px 1px;font:normal 12px Tahoma;">
		Dear <?php echo '<span style="font-weight:bold;">'.ucfirst($user_name).'</span>'; ?>, <br/><br/>
		Your bussiness profile received an enquiry notifications from <?php echo ucfirst($customer_name);?>.In order to view enquiry notifications. please <?php echo anchor(base_url().'login','Click here'); ?><br/>
		<br/><br/>
	 <br/>     
</tr>