<div class=td-footer-wrapper>
    <div class=td-sub-footer-container>
        <div class=td-container>
            <div class=td-pb-row>
                <div class="td-pb-span7 td-sub-footer-menu">
                    <div class=menu-footer-menu-container>
                        <ul id=menu-footer-menu class=td-subfooter-menu>
                            <li id=menu-item-158 class="menu-item menu-item-type-custom menu-item-object-custom menu-item-first td-menu-item td-normal-menu menu-item-158"><a href="<?php echo base_url();?>">Home</a>
                            </li>
                            <li id=menu-item-159 class="menu-item menu-item-type-custom menu-item-object-custom td-menu-item td-normal-menu menu-item-159"><a href="<?php echo base_url().'blogs';?>">Blogs</a>
                            </li>
                            <li id=menu-item-161 class="menu-item menu-item-type-custom menu-item-object-custom td-menu-item td-normal-menu menu-item-161"><a href="<?php echo base_url().'privacy-policy'; ?>">Privacy Policy</a>
                            </li>
                            <li id=menu-item-162 class="menu-item menu-item-type-custom menu-item-object-custom td-menu-item td-normal-menu menu-item-162"><a href="<?php echo base_url().'contact-us'; ?>">Contact us</a>
                            </li>
							<li id=menu-item-162 class="menu-item menu-item-type-custom menu-item-object-custom td-menu-item td-normal-menu menu-item-162"><a href="<?php echo base_url().'about-us'; ?>">About us</a>
                            </li>
							<li id=menu-item-162 class="menu-item menu-item-type-custom menu-item-object-custom td-menu-item td-normal-menu menu-item-162"><a href="<?php echo base_url().'claim-my-bussiness'; ?>">Claim My Bussiness</a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="td-pb-span5 td-sub-footer-copy">
                    &copy; Dragdeal.com -
                    <?php echo date( "Y");?> </div>
            </div>
        </div>
    </div>
<script type='text/javascript' src='<?php echo base_url().'assets/themes/js/jquery.blockUI.min.js '?>'></script>
<script type='text/javascript' src='<?php echo base_url().'assets/themes/js/dialbetheme.min.js '?>'></script>
<script type='text/javascript' src='<?php echo base_url().'assets/themes/js/wp-embed.min.js '?>'></script>
<script type='text/javascript' src='<?php echo base_url().'assets/themes/js/js_composer_front.min.js '?>'></script>
<script type='text/javascript' src='<?php echo base_url().'assets/js/jquery.livequery.js';?>'></script>
<script type='text/javascript' src='<?php echo base_url().'assets/js/jquery.amaran.js';?>'></script>
<script type='text/javascript' src="<?php echo base_url();?>assets/customer/js/loadingoverlay.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/jquery-ui.min.js"></script>
<script type='text/javascript' src='<?php echo base_url().'assets/themes/js/main.js';?>'></script>