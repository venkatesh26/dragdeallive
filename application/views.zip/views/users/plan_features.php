			
			<?Php if($this->detect->isMobile()):?>
			<div class="col-lg-4 js-plan-1-feature plan-feature" style="min-height:180px !important;">
                                 <h4><i class="fa fa-gift color-green-icon"></i> Plan Features </h4>
                                 <ul class="plan-feature-list">
                                    <li> <i class="fa fa-check-circle-o color-green-icon"></i> Premium Listing</li>
                                    <li> <i class="fa fa-check-circle-o color-green-icon"></i> Email Leads</li>
                                    <li> <i class="fa fa-check-circle-o color-green-icon"></i> One Time Activation</li>
                                    <li> <i class="fa fa-check-circle-o color-green-icon"></i> Multiple Keywords</li>
                                    <li> <i class="fa fa-check-circle-o color-green-icon"></i> Free SEO</li>
                                 </ul>
                              </div>
                              <div class="col-lg-2 js-plan-2-feature plan-feature" style="display:none;min-height:180px !important;">
                                 <h4><i class="fa fa-gift color-green-icon"></i> Plan Features </h4>
                                 <ul class="plan-feature-list js-plan-2-feature">
                                    <li> <i class="fa fa-check-circle-o color-green-icon"></i> Premium Listing</li>
                                    <li> <i class="fa fa-check-circle-o color-green-icon"></i> Email Leads</li>
                                    <li> <i class="fa fa-check-circle-o color-green-icon"></i> One Time Activation</li>
                                    <li> <i class="fa fa-check-circle-o color-green-icon"></i> Multiple Keywords</li>
                                    <li> <i class="fa fa-check-circle-o color-green-icon"></i> Manage Customer</li>
									    <li> <i class="fa fa-check-circle-o color-green-icon"></i> 200 Sms</li>
                                    <li> <i class="fa fa-check-circle-o color-green-icon"></i> Limited Coupons</li>
                                    <li> <i class="fa fa-check-circle-o color-green-icon"></i> Free SEO</li>
                                 </ul>
                              </div>
     
                              <div class="col-lg-2 js-plan-3-feature plan-feature" style="display:none;min-height:180px !important;">
                                 <h4><i class="fa fa-gift color-green-icon"></i> Plan Features </h4>
                                 <ul class="plan-feature-list js-plan-3-feature">
                                    <li> <i class="fa fa-check-circle-o color-green-icon"></i> Premium Listing</li>
                                    <li> <i class="fa fa-check-circle-o color-green-icon"></i> Email Leads</li>
                                    <li> <i class="fa fa-check-circle-o color-green-icon"></i> One Time Activation</li>
                                    <li> <i class="fa fa-check-circle-o color-green-icon"></i> Multiple Keywords</li>
                                    <li> <i class="fa fa-check-circle-o color-green-icon"></i> Manage Customer</li>
									<li> <i class="fa fa-check-circle-o color-green-icon"></i> 400 Sms</li>
                                    <li> <i class="fa fa-check-circle-o color-green-icon"></i> UnLimited Coupons</li>
                                    <li> <i class="fa fa-check-circle-o color-green-icon"></i> Free SEO</li>
                                 </ul>
                              </div>
						<?php else:?>	  
							  
							<div class="col-lg-4 js-plan-1-feature plan-feature" style="min-height:180px !important;">
                                 <h4><i class="fa fa-gift color-green-icon"></i> Plan Features </h4>
                                 <ul class="plan-feature-list">
                                    <li> <i class="fa fa-check-circle-o color-green-icon"></i> Premium Listing</li>
                                    <li> <i class="fa fa-check-circle-o color-green-icon"></i> Email Leads</li>
                                    <li> <i class="fa fa-check-circle-o color-green-icon"></i> One Time Activation</li>
                                    <li> <i class="fa fa-check-circle-o color-green-icon"></i> Multiple Keywords</li>
                                    <li> <i class="fa fa-check-circle-o color-green-icon"></i> Free SEO</li>
                                 </ul>
                              </div>
                              <div class="col-lg-2 js-plan-2-feature plan-feature" style="display:none;min-height:180px !important;">
                                 <h4><i class="fa fa-gift color-green-icon"></i> Plan Features </h4>
                                 <ul class="plan-feature-list js-plan-2-feature">
                                    <li> <i class="fa fa-check-circle-o color-green-icon"></i> Premium Listing</li>
                                    <li> <i class="fa fa-check-circle-o color-green-icon"></i> Email Leads</li>
                                    <li> <i class="fa fa-check-circle-o color-green-icon"></i> One Time Activation</li>
                                    <li> <i class="fa fa-check-circle-o color-green-icon"></i> Multiple Keywords</li>
                                    <li> <i class="fa fa-check-circle-o color-green-icon"></i> Manage Customer</li>
                                 </ul>
                              </div>
                              <div class="col-lg-2 js-plan-2-feature plan-feature" style="display:none;min-height:180px !important;">
                                 <ul class="plan-feature-list js-plan-2-feature feature-add-list" style="display:none;">
                                    <li> <i class="fa fa-check-circle-o color-green-icon"></i> 200 Sms</li>
                                    <li> <i class="fa fa-check-circle-o color-green-icon"></i> Limited Coupons</li>
                                    <li> <i class="fa fa-check-circle-o color-green-icon"></i> Free SEO</li>
                                 </ul>
                              </div>
                              <div class="col-lg-2 js-plan-3-feature plan-feature" style="display:none;min-height:180px !important;">
                                 <h4><i class="fa fa-gift color-green-icon"></i> Plan Features </h4>
                                 <ul class="plan-feature-list js-plan-3-feature">
                                    <li> <i class="fa fa-check-circle-o color-green-icon"></i> Premium Listing</li>
                                    <li> <i class="fa fa-check-circle-o color-green-icon"></i> Email Leads</li>
                                    <li> <i class="fa fa-check-circle-o color-green-icon"></i> One Time Activation</li>
                                    <li> <i class="fa fa-check-circle-o color-green-icon"></i> Multiple Keywords</li>
                                    <li> <i class="fa fa-check-circle-o color-green-icon"></i> Manage Customer</li>
                                 </ul>
                              </div>
                              <div class="col-lg-2 js-plan-3-feature plan-feature" style="display:none;min-height:180px !important;">
                                 <ul class="plan-feature-list js-plan-3-feature feature-add-list" style="marign-top:40px;">
                                    <li> <i class="fa fa-check-circle-o color-green-icon"></i> 400 Sms</li>
                                    <li> <i class="fa fa-check-circle-o color-green-icon"></i> UnLimited Coupons</li>
                                    <li> <i class="fa fa-check-circle-o color-green-icon"></i> Free SEO</li>
                                 </ul>
                              </div>  
                              
							  <?php endif;?>