<div class="login-main">
	<div class="login-inner">
		<h2>Forgot Password</h2>
		<form id="forgotpassword_url" action="<?php echo base_url().'users/forgot_password';?>" method="post">
			<div class="input">
				<input type="text" name="email_address" placeholder="Your E-mail ID" />
			</div>
			<div class="submit">
				<input type="submit" name="submit" value="Submit" title="Submit" />
			</div>			
		</form>
	</div>
</div>
