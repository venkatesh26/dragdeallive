<div class="td-main-content-wrap">
<div class="td-container td-post-template-2">
<article itemscope="" class="post-63 post type-post status-publish format-standard has-post-thumbnail hentry category-tagdiv-photography" id="post-63">
<div class="td-pb-row">
	<div class="td-pb-span12">
			<div class="td-post-header">
			<div class="td-crumb-container"><div class="entry-crumbs"><span itemtype="http://data-vocabulary.org/Breadcrumb" itemscope=""><a href="http://demo.tagdiv.com/newspaper_tech/" itemprop="url" class="entry-crumb" title=""><span itemprop="title">Home</span></a></span> <i class="td-icon-right td-bread-sep"></i> <span itemtype="http://data-vocabulary.org/Breadcrumb" itemscope=""><a href="http://demo.tagdiv.com/newspaper_tech/category/tagdiv-photography/" itemprop="url" class="entry-crumb" title="View all posts in Photography"><span itemprop="title">Photography</span></a></span> <i class="td-icon-right td-bread-sep td-bred-no-url-last"></i> <span itemtype="http://data-vocabulary.org/Breadcrumb" itemscope="" class="td-bred-no-url-last"><meta content="Mathematica 10 released on Raspberry Pi" itemprop="title"><meta content="http://demo.tagdiv.com/newspaper_tech/td-post-mathematica-10-released-on-raspberry-pi/" itemprop="url">Mathematica 10 released on Raspberry Pi</span></div></div>
			<header class="td-post-title">
			<h1 class="entry-title"><?php echo nl2br($my_content['title']);?></h1>
			<div class="td-module-meta-info">
			</header>
			</div>
			</div>
	</div>
</div>
<div class="td-pb-row">
		<div role="main" class="td-pb-span12 td-main-content">
				<div class="td-ss-main-content">
				<div class="clearfix"></div>
				<div class="td-post-content">
					<div class="td-paragraph-padding-1">
					<?php echo nl2br($my_content['content']);?>
					</div>
				</div>
				</div>
		</div>
</div>
</article>
</div>
</div>