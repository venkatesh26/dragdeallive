<div class="" style="width:673px;height:100px;">
 <?php
if($this->config->item('is_live_site'))
{?>
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
							<!-- dialbe new -->
							<ins class="adsbygoogle"
							style="display:block;"
							data-ad-client="ca-pub-2739505616311307"
							data-ad-slot="8765715278"
							data-ad-format="auto"></ins>
							<script>
							(adsbygoogle = window.adsbygoogle || []).push({});
</script>
<?php
}?>			
</div>