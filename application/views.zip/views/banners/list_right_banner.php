
<h3 class="header-title">Advertisment</h3>
<?php
if($this->config->item('is_live_site'))
{?>
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- List New -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-2739505616311307"
     data-ad-slot="8926929278"
     data-ad-format="auto"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
<br/>
<br/>
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- DIALBE -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-2739505616311307"
     data-ad-slot="4345202074"
     data-ad-format="auto"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
<?php
}?>							