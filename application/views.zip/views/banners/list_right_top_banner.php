<h3 class="header-title">Advertisment</h3>
<div class="rightsection">
<?php
if($this->config->item('is_live_site'))
{?>
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- list left top banner -->
<ins class="adsbygoogle"
     style="display:inline-block;width:160px;height:600px"
     data-ad-client="ca-pub-2739505616311307"
     data-ad-slot="4345202074"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
<?php
}?>						
</div>