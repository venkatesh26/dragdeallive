<div class="td-pb-span4 td-main-sidebar">
<div class="td-ss-main-sidebar" style="width: auto; position: static; top: auto; bottom: auto;">
<div class="clearfix"></div>

<aside class="widget_categories list_page_section1">
<h3 class="entry-title td-page-title" style="display:block;background-color:#29c065;padding:3px;color:#fff;text-align:center;"> Advertisements</h3>
 <div>
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- newtheme customsize -->
<ins class="adsbygoogle"
     style="display:inline-block;width:300px;height:250px"
     data-ad-client="ca-pub-2739505616311307"
     data-ad-slot="2323491279"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
                                </div>
                                
                     
</aside>
    <?php
    if($this->detect->isMobile() || $this->detect->isTablet()):?>	

<?php else:?>
      <aside class="widget widget_categories widget_recent_entries">
								<div class="td-a-rec td-a-rec-id-sidebar "><span class=td-adspot-title>- Advertisement -</span>
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- List Page Add -->
<ins class="adsbygoogle"
     style="display:inline-block;width:300px;height:250px"
     data-ad-client="ca-pub-2739505616311307"
     data-ad-slot="8537965923"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
</div>
                                
                            </aside>
                            <?php endif;?>
</div>
</div>